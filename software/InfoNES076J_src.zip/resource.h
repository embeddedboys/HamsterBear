//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by InfoNES.rc
//
#define IDR_MENU                        101
#define IDR_MAINDUMMY                   40003
#define IDM_MAIN_END                    40006
#define IDM_MAIN_RESUME                 40007
#define IDM_MAIN_RESET                  40008
#define IDM_MAIN_FRAME_0                40009
#define IDM_MAIN_FRAME_1                40010
#define IDM_MAIN_FRAME_2                40011
#define IDM_MAIN_FRAME_3                40012
#define IDM_MAIN_FRAME_4                40013
#define IDM_MAIN_FRAME_5                40014
#define IDM_MAIN_FRAME_8                40015
#define IDM_MAIN_FRAME_10               40016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40017
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
